package com.entertainment.unique_tictactoe.ui.theme

import androidx.compose.ui.graphics.Color

val Purple200 = Color(0xFFBB86FC)
val Purple500 = Color(0xFF6200EE)
val Purple700 = Color(0xFF3700B3)
val Teal200 = Color(0xFF03DAC5)

val GrayBackground = Color(0xFFf5f7f6)
val StatusBarColor = Color(0xF5F7F6)
val Gray = Color(0xFF919191)
val BlueCustom = Color(0xFF2196F3)